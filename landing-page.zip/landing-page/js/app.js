/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/
const sections = document.querySelectorAll('section');
const ulNavBar = document.getElementById('navbar__list');
const fragmentOne = document.createDocumentFragment();


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/


function removeActiveClass (){
document.querySelectorAll('li').forEach((li)=>{
li.classList.remove("active");
})
}

function addActiveClass (dataNav) {    
document.querySelectorAll('li').forEach((li)=>{
   if(li.textContent==dataNav){
    li.classList.add("active");
   }
})
}

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav

for(let i = 0 ; i < sections.length ; i++){
    const newElementOne = document.createElement('li');
    const newElementTwo = document.createElement('a');
    const data = sections[i].getAttribute("data-nav");
    newElementTwo.textContent=data;
    newElementOne.appendChild(newElementTwo);
    
    fragmentOne.appendChild(newElementOne);
    newElementTwo.addEventListener('click',()=>{
    sections[i].scrollIntoView({behavior: "smooth"});
    })
}

ulNavBar.appendChild(fragmentOne);


// Add class 'active' to section when near top of viewport

document.addEventListener('scroll',function () {
//get current scroll position
const scrollPosition = document.documentElement.scrollTop;
//check scroll position to see which section meets the scroll position
 sections.forEach((section)=>{
 if (scrollPosition >=section.offsetTop-section.offsetHeight*0.1 && scrollPosition< section.offsetTop+section.offsetHeight)
 {
 const dataAttribute = section.getAttribute("data-nav");
 removeActiveClass();
 addActiveClass(dataAttribute);
 }
 });   
});



// Scroll to anchor ID using scrollTO event



/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


