# Landing Page Project
This Project Done By : Mina Yousry
All Rights are Reserverd

## Table of Contents

* [Instructions](#instructions)

## Instructions

This project has some HTML and CSS styling to display a interactive version of the Landing Page project. 
It's contains a javaScript file includes all functions and Events needed to make this project interactive one.
The HTML and CSS files are modified.



